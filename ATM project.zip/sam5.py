num = int(input("number: "))
if num%4==0:
    print("its leap year")
else:
    print("not leap year")
